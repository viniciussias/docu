# frozen_string_literal: true

Oj.optimize_rails
