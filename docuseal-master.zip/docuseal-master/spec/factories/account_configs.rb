# frozen_string_literal: true

FactoryBot.define do
  factory :account_config do
    account
  end
end
